//SERVER 
const app = require('express')();
const server = require('http').Server(app);
const io = require('socket.io')(server);
const port = 3000;

server.listen(port, () =>{
    console.log(`Server is running on port ${port}`);
});

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/public/index.html');
});

app.get('/gamers', (req, res) => {
    res.sendFile(__dirname + '/public/gamers.html');
});

app.get('/newbies', (req, res) => {
    res.sendFile(__dirname + '/public/newbies.html');
});

app.get('/veterans', (req, res) => {
    res.sendFile(__dirname + '/public/veterans.html');
});

app.get('/online', (req, res) => {
    res.sendFile(__dirname + '/public/online.html');
});

app.get('/showoff', (req, res) => {
    res.sendFile(__dirname + '/public/showoff.html');
});

// creating a name space which is a separation for chat rooms
const gamers = io.of('/gamers');

gamers.on('connection', (socket) => {
    //listening to join even which is part of socket.io API
    socket.on('join', (data) => {
        //passing the data and joining the newusers room
        socket.join(data.room);
        //emit a message to users in the newusers room
        gamers.in(data.room).emit('message', `New user joined the ${data.room} chat!`);
    })

    //listening to a message event and passing the data
    socket.on('message', (data) => {
        console.log(`message: ${data.msg}`);
        gamers.in(data.room).emit('message', data.msg);
    });

    //socket listening event for when a client disconnects
    socket.on('disconnect', () => {
        console.log('user disconnected');

        //message event will show when user disconnects
        gamers.emit('message', 'user disconnected');
    })
})
